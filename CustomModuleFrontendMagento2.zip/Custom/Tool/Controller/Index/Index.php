<?php

namespace Custom\Tool\Controller\Index;

class Index extends \Magento\Framework\App\Action\Action
{
    public function execute()
    {
	echo "hi";die;
        $this->_view->loadLayout();
        $this->_view->getLayout()->initMessages();
        $this->_view->renderLayout();
    }
}
