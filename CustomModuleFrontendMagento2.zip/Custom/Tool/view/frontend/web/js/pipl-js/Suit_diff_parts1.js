if (!Detector.webgl)
    Detector.addGetWebGLMessage();
var STATS_ENABLED = false;
var CARS = {
    "gallardo": {
        name: "Lamborghini Gallardo",
        url: "Suit_obj/Shirt_2.js",
        init_rotation: [0, 0, 0],
        scale: 15,
        init_material: 0,
        body_materials: [2],
        object: null,
        buttons: null,
        materials: null

    },
};
var container, stats;
var camera, scene, renderer;
var m, mi;
var obj;
var basePath;
// var targetRotationX = 0;
// var targetRotationOnMouseDownX = 0;

var targetRotation = 0;
var targetRotationOnMouseDown = 0;
// var mouseX = 0;
var mouseXOnMouseDown = 0;
var directionalLight, pointLight;
var mouseX = 0, mouseY = 0;
var windowHalfX = window.innerWidth / 2;
var windowHalfY = window.innerHeight / 2;
var loader = new THREE.BinaryLoader();






jQuery(document).ready(function() {
    basePath = jQuery("#basePath").val();

});
init();
animate();
function init() {

    container = document.getElementById('canvasHolder');


    //document.body.appendChild(container);
    // CAMERAS

    camera = new THREE.PerspectiveCamera(11.8, window.innerWidth / window.innerHeight, 10, 2000);
    camera.position.z = 450;
    //camera.position.x = 5200;
    camera.position.y = 25;
    scene = new THREE.Scene();
    // LIGHTS

    var ambient = new THREE.AmbientLight(0x050505);
    scene.add(ambient);
   /* directionalLight = new THREE.DirectionalLight(0xffffff, 1.1);
    directionalLight.position.set(2, 1.2, 10).normalize();
    scene.add(directionalLight);*/
    
    directionalLight = new THREE.DirectionalLight(0xffffff, 1);
    directionalLight.position.set(0.5, 1.2, 10).normalize();
    scene.add(directionalLight);

    directionalLight = new THREE.DirectionalLight(0xffffff, 0.5);
    directionalLight.position.set(-2, 1.2, -10).normalize();
    scene.add(directionalLight);

    //point-light
    pointLight = new THREE.PointLight(0xffffff, 0.09);
    pointLight.position.set(500, 500, 500);
    scene.add(pointLight);

    //

    renderer = new THREE.WebGLRenderer();
    renderer.setPixelRatio(window.devicePixelRatio);
    renderer.setSize(window.innerWidth, window.innerHeight);
    // renderer.setFaceCulling(THREE.CullFaceNone);
    renderer.setClearColor(0xC1D7FB, 3);

    container.appendChild(renderer.domElement);
    document.addEventListener('mousedown', onDocumentMouseDown, false);
    document.addEventListener('touchstart', onDocumentTouchStart, false);
    document.addEventListener('touchmove', onDocumentTouchMove, false);
    window.addEventListener('resize', onWindowResize, false);
    if (STATS_ENABLED) {

        stats = new Stats();
        container.appendChild(stats.dom);
    }




    var mlib = {
        //apply different colors.
        //                    "Orange": new THREE.MeshLambertMaterial({color: 0xff6600 /*envMap: textureCube, combine: THREE.MixOperation, reflectivity: 0.3*/}),
        //                    "Blue": new THREE.MeshLambertMaterial({color: 0x001133/* envMap: textureCube, combine: THREE.MixOperation, reflectivity: 0.3*/}),
        //                    "Red": new THREE.MeshLambertMaterial({color: 0x660000/* envMap: textureCube, combine: THREE.MixOperation, reflectivity: 0.25}*/}),
        //                    "Black": new THREE.MeshLambertMaterial({color: 0x000000/* envMap: textureCube, combine: THREE.MixOperation, reflectivity: 0.15*/}),
        //                    "White": new THREE.MeshLambertMaterial({color: 0xffffff/* envMap: textureCube, combine: THREE.MixOperation, reflectivity: 0.25*/}),

        "Orange": new THREE.MeshLambertMaterial({map: THREE.ImageUtils.loadTexture('textures/01.jpg')}),
        "Blue": new THREE.MeshLambertMaterial({map: THREE.ImageUtils.loadTexture('textures/02.jpg')}),
        "Red": new THREE.MeshLambertMaterial({map: THREE.ImageUtils.loadTexture('textures/03.jpg')}),
        "Black": new THREE.MeshLambertMaterial({map: THREE.ImageUtils.loadTexture('textures/04.jpg')}),
        //"Red": new THREE.MeshLambertMaterial({color: 0xff6600}),
        "AAA": new THREE.MeshLambertMaterial({map: THREE.ImageUtils.loadTexture('textures/05.jpg')}),
        "GreenF": new THREE.MeshLambertMaterial({map: THREE.ImageUtils.loadTexture('textures/06.png')}),
        "Red1": new THREE.MeshLambertMaterial({map: THREE.ImageUtils.loadTexture('textures/07.png')}),
        "purple": new THREE.MeshLambertMaterial({map: THREE.ImageUtils.loadTexture('textures/08.png')}),
        "gray": new THREE.MeshLambertMaterial({map: THREE.ImageUtils.loadTexture('textures/09.png')}),
        "black": new THREE.MeshLambertMaterial({map: THREE.ImageUtils.loadTexture('textures/10.png')}),
        "new-gray": new THREE.MeshLambertMaterial({map: THREE.ImageUtils.loadTexture('textures/11.png')}),
        /* envMap: textureCube, combine: THREE.MixOperation, reflectivity: 0.15*/

        /*"Carmine": new THREE.MeshPhongMaterial({color: 0x770000, specular: 0xffaaaa, envMap: textureCube, combine: THREE.MultiplyOperation}),
         "Gold": new THREE.MeshPhongMaterial({color: 0xaa9944, specular: 0xbbaa99, shininess: 50, envMap: textureCube, combine: THREE.MultiplyOperation}),
         "Bronze": new THREE.MeshPhongMaterial({color: 0x150505, specular: 0xee6600, shininess: 10, envMap: textureCube, combine: THREE.MixOperation, reflectivity: 0.25}),
         "Chrome": new THREE.MeshPhongMaterial({color: 0xffffff, specular: 0xffffff, envMap: textureCube, combine: THREE.MultiplyOperation}),
         "Orange metal": new THREE.MeshLambertMaterial({color: 0xff6600, envMap: textureCube, combine: THREE.MultiplyOperation}),
         "Blue metal": new THREE.MeshLambertMaterial({color: 0x001133, envMap: textureCube, combine: THREE.MultiplyOperation}),
         "Red metal": new THREE.MeshLambertMaterial({color: 0x770000, envMap: textureCube, combine: THREE.MultiplyOperation}),
         "Green metal": new THREE.MeshLambertMaterial({color: 0x007711, envMap: textureCube, combine: THREE.MultiplyOperation}),
         "Black metal": new THREE.MeshLambertMaterial({color: 0x222222, envMap: textureCube, combine: THREE.MultiplyOperation}),
         "Pure chrome": new THREE.MeshLambertMaterial({color: 0xffffff, envMap: textureCube}),
         "Dark chrome": new THREE.MeshLambertMaterial({color: 0x444444, envMap: textureCube}),
         "Darker chrome": new THREE.MeshLambertMaterial({color: 0x222222, envMap: textureCube}),
         "Black glass": new THREE.MeshLambertMaterial({color: 0x101016, envMap: textureCube, opacity: 0.975, transparent: true}),
         "Dark glass": new THREE.MeshLambertMaterial({color: 0x101046, envMap: textureCube, opacity: 0.25, transparent: true}),
         "Blue glass": new THREE.MeshLambertMaterial({color: 0x668899, envMap: textureCube, opacity: 0.75, transparent: true}),
         "Light glass": new THREE.MeshBasicMaterial({color: 0x223344, envMap: textureCube, opacity: 0.25, transparent: true, combine: THREE.MixOperation, reflectivity: 0.25}),
         "Red glass": new THREE.MeshLambertMaterial({color: 0xff0000, opacity: 0.75, transparent: true}),
         "Yellow glass": new THREE.MeshLambertMaterial({color: 0xffffaa, opacity: 0.75, transparent: true}),
         "Orange glass": new THREE.MeshLambertMaterial({color: 0x995500, opacity: 0.75, transparent: true}),
         "Orange glass 50": new THREE.MeshLambertMaterial({color: 0xffbb00, opacity: 0.5, transparent: true}),
         "Red glass 50": new THREE.MeshLambertMaterial({color: 0xff0000, opacity: 0.5, transparent: true}),
         "Fullblack rough": new THREE.MeshLambertMaterial({color: 0x000000}),
         "Black rough": new THREE.MeshLambertMaterial({color: 0x050505}),
         "Darkgray rough": new THREE.MeshLambertMaterial({color: 0x090909}),
         "Red rough": new THREE.MeshLambertMaterial({color: 0x330500}),
         "Darkgray shiny": new THREE.MeshPhongMaterial({color: 0x000000, specular: 0x050505}),
         "Gray shiny": new THREE.MeshPhongMaterial({color: 0x050505, shininess: 20})*/

    };
    // Gallardo materials

    CARS[ "gallardo" ].materials = {
        body: [
            ["01.jpg", mlib[ "Orange" ]],
            ["02.jpg", mlib[ "Blue" ]],
            ["03.jpg", mlib[ "Red" ]],
            ["04.jpg", mlib[ "Black" ]],
            ["05.jpg", mlib[ "AAA" ]],
            ["06.png", mlib[ "GreenF" ]],
            ["07.png", mlib[ "Red1" ]],
            ["08.png", mlib[ "purple" ]],
            ["09.png", mlib[ "gray" ]],
            ["10.png", mlib[ "black" ]]
          

                    /*  ["Orange", mlib[ "White" ]],
                     ["Red", mlib[ "Green" ]]*/
        ]

    };
    m = CARS[ "gallardo" ].materials;
    mi = CARS[ "gallardo" ].init_material;
    CARS[ "gallardo" ].mmap = {
        0: m.body[ mi ][ 1 ], // hand
        1: m.body[ mi ][ 1 ], // Cuff
        2: m.body[ mi ][ 0 ],
        3: m.body[ mi ][ 1 ], // hand
        4: m.body[ mi ][ 1 ], // cuff
        5: m.body[ mi ][ 1 ], //inner-side
        6: m.body[ mi ][ 1 ], //collar
        7: m.body[ mi ][ 1 ] //buttons
       


    };
    loader.load(CARS[ "gallardo" ].url, function(geometry) {
        createScene(geometry, "gallardo")
    });
    //object=geometry;


    for (var c in CARS)
        initCarButton(c);
    //

    //window.addEventListener('resize', onWindowResize, false);

}

function initCarButton(car) {

    $(car).addEventListener('click', function() {

        if (!CARS[ car ].object) {

            loader.load(CARS[ car ].url, function(geometry) {
                createScene(geometry, car)
            });
        } else {

            switchCar(car);
        }

    }, false);
}

function $(id) {
    return document.getElementById(id);
}
function button_name(car, index) {
    return "m_" + car + "_" + index
}



function createButtons(materials, car) {

    var buttons, i, src = "";
    for (i = 0; i < materials.length; i++) {

        src += '<li id="' + button_name(car, i) + '" onclick="changeColor(this)"><img width="90" height="90" src="' + basePath + 'textures/' + materials[ i ][ 0 ] + '"/></li> ';
    }

    buttons = document.createElement("ul");
    buttons.innerHTML = src;
    document.getElementById("buttons_materials").appendChild(buttons);
    return buttons;
}

function attachButtonMaterials(materials, faceMaterial, material_indices, car) {

    for (var i = 0; i < materials.length; i++) {

        document.getElementById(button_name(car, i)).counter = i;
        document.getElementById(button_name(car, i)).addEventListener('click', function() {

            if (car == 'gallardo')
            {
                var selPart = document.querySelector('input[name="optColor"]:checked').value;
                if (selPart == 'body') {
                    //faceMaterial.materials[3] = materials[ this.counter ][ 1 ];
                    faceMaterial.materials[8] = materials[ this.counter ][ 1 ];
                }
                if (selPart == 'hands') {
                    faceMaterial.materials[0] = materials[ this.counter ][ 1 ];
                    faceMaterial.materials[3] = materials[ this.counter ][ 1 ];
                }
                if (selPart == 'collar') {
                    faceMaterial.materials[6] = materials[ this.counter ][ 1 ];
                }
                if (selPart == 'cuff') {
                    faceMaterial.materials[1] = materials[ this.counter ][ 1 ];
                    faceMaterial.materials[4] = materials[ this.counter ][ 1 ];
                }
                if (selPart == 'btn') {
                    faceMaterial.materials[7] = materials[ this.counter ][ 1 ];
                    //faceMaterial.materials[4] = materials[ this.counter ][ 1 ];
                }
                if (selPart == 'back-side') {
                    faceMaterial.materials[5] = materials[ this.counter ][ 1 ];
                    //faceMaterial.materials[4] = materials[ this.counter ][ 1 ];
                }
                /* if (selPart == 'hide') {
                 faceMaterial.materials[1] = materials[ this.counter ][ 0 ];
                 faceMaterial.materials[8] = materials[ this.counter ][ 0 ];
                 
                 }*/

                return;
            }

            for (var j = 0; j < material_indices.length; j++) {



                faceMaterial.materials[ material_indices [ j ] ] = materials[ this.counter ][ 1 ];
            }

        }, false);
    }

    setTimeout(function() {
        jQuery("#theInitialProgress").hide();
        jQuery("#buttons_materials li").eq(2).trigger("click");
    }, 500);

}

/*  function funHide() {
 
 if (car == 'gallardo') {
 var selPart = document.querySelector('input[name="optColor"]:checked').value;
 
 if (selPart == 'hide') {
 faceMaterial.materials[1] = materials[ this.counter ][ 0 ];
 faceMaterial.materials[8] = materials[ this.counter ][ 0 ];
 }
 
 }
 for (var j = 0; j < material_indices.length; j++) {
 
 
 
 faceMaterial.materials[ material_indices [ j ] ] = materials[ this.counter ][ 1 ];
 
 }
 }*/


var theCurrentCarM;
function createScene(geometry, car) {

    geometry.sortFacesByMaterialIndex();
    theCurrentCarM = new THREE.MultiMaterial(),
            s = CARS[ car ].scale * 2,
            r = CARS[ car ].init_rotation,
            materials = CARS[ car ].materials,
            mi = CARS[ car ].init_material,
            bm = CARS[ car ].body_materials;
    for (var i in CARS[ car ].mmap) {

        theCurrentCarM.materials[ i ] = CARS[ car ].mmap[ i ];
    }

    obj = new THREE.Mesh(geometry, theCurrentCarM);
    scene.add(obj);
    CARS[ car ].buttons = createButtons(materials.body, car);
    attachButtonMaterials(materials.body, theCurrentCarM, bm, car);
    //switchCar(car);
}



function onWindowResize() {

    windowHalfX = window.innerWidth / 2;
    windowHalfY = window.innerHeight / 2;
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
}


function onDocumentMouseDown(event) {

    event.preventDefault();
    document.addEventListener('mousemove', onDocumentMouseMove, false);
    document.addEventListener('mouseup', onDocumentMouseUp, false);
    document.addEventListener('mouseout', onDocumentMouseOut, false);
    mouseXOnMouseDown = event.clientX - windowHalfX;
    targetRotationOnMouseDown = targetRotation;
}


function onDocumentMouseMove(event) {

    mouseX = event.clientX - windowHalfX;
    targetRotation = targetRotationOnMouseDown + (mouseX - mouseXOnMouseDown) * 0.02;
    console.log("target_rotation=" + targetRotation);
}


function onDocumentMouseUp(event) {

    document.removeEventListener('mousemove', onDocumentMouseMove, false);
    document.removeEventListener('mouseup', onDocumentMouseUp, false);
    document.removeEventListener('mouseout', onDocumentMouseOut, false);
}


function onDocumentMouseOut(event) {

    document.removeEventListener('mousemove', onDocumentMouseMove, false);
    document.removeEventListener('mouseup', onDocumentMouseUp, false);
    document.removeEventListener('mouseout', onDocumentMouseOut, false);
}


function onDocumentTouchStart(event) {

    if (event.touches.length === 1) {

        event.preventDefault();
        mouseXOnMouseDown = event.touches[ 0 ].pageX - windowHalfX;
        targetRotationOnMouseDown = targetRotation;
    }

}


function onDocumentTouchMove(event) {

    if (event.touches.length === 1) {

        event.preventDefault();
        mouseX = event.touches[ 0 ].pageX - windowHalfX;
        targetRotation = targetRotationOnMouseDown + (mouseX - mouseXOnMouseDown) * 0.05;
    }

}


function animate() {

    requestAnimationFrame(animate);
    render();
}

function render() {

    if (obj) {
        obj.rotation.y += (targetRotation - obj.rotation.y) *0.19;
        renderer.render(scene, camera);
    }
}



function changeColor(actObj)
{

    jQuery("#buttons_materials").find(".active").removeClass("active");
    jQuery(actObj).addClass("active");
}