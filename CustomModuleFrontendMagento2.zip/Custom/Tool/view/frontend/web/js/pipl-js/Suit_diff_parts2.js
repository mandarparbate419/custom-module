/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */




if (!Detector.webgl)
    Detector.addGetWebGLMessage();
var STATS_ENABLED = false;
var objName;
var OBJECT = {
    "obj_one": {
        url: "Suit_obj/Crew.js",
        init_material: 0,
        materials: null

    }
};
var container, stats;
var camera, scene, renderer;
var m, mi;
var obj, fov;
var canvasHt = 600;
var canvasWt = 600;




var targetRotation = 0;
var targetRotationOnMouseDown = 0;

var mouseXOnMouseDown = 0;
var directionalLight, pointLight;
var mouseX = 0, mouseY = 0;
//var windowHalfX = window.innerWidth / 2;
//var windowHalfY = window.innerHeight / 2;
var loader = new THREE.BinaryLoader();
var light;
var mlib = {};
OBJECT["obj_one"].materials = {};

/* function onResize(element, callback) {
        var height = element.clientHeight;
        var width  = element.clientWidth;
        
        return setInterval(function() {
            if (element.clientHeight != height || element.clientWidth != width) {
              height = element.clientHeight;
              width  = element.clientWidth;
              callback();
            }
        }, 500);
      }*/

function init() {

    container = document.getElementById('canvasHolder');


    //document.body.appendChild(container);
    // CAMERAS

    // camera = new THREE.PerspectiveCamera(fov = 15, window.innerWidth / window.innerHeight, 10, 2000);
    camera = new THREE.PerspectiveCamera(14, canvasWt / canvasHt, 0.1, 1000);

    camera.position.z = 450;
    // camera.position.x = 30;
    camera.position.y = 30;
    scene = new THREE.Scene();
    // LIGHTS

    var ambient = new THREE.AmbientLight(0x050505);
    //0x050505
    scene.add(ambient);
    var ambient = new THREE.AmbientLight(0x050505);
    scene.add(ambient);
    directionalLight = new THREE.DirectionalLight(0xffffff, 0.99);
    directionalLight.position.set(2, 1.2, 10).normalize();
    scene.add(directionalLight);

    directionalLight = new THREE.DirectionalLight(0xffffff, 0.7);
    directionalLight.position.set(-2, 1.2, -10).normalize();
    scene.add(directionalLight);

    //point-light
    pointLight = new THREE.PointLight(0xffffff, 0.09);
    pointLight.position.set(500, 500, 500);
    scene.add(pointLight);


    //

    renderer = new THREE.WebGLRenderer({});
    renderer.setPixelRatio(window.devicePixelRatio);
    renderer.setViewport(0, 0, canvasWt, canvasHt);
    renderer.setSize(canvasWt, canvasHt);
    renderer.shadowMapType = THREE.PCFSoftShadowMap;

    //renderer.setSize(window.innerWidth, window.innerHeight);
    // renderer.setFaceCulling(THREE.CullFaceNone);
    renderer.setClearColor(0xFFFFFF, 1.0);

    container.appendChild(renderer.domElement);
    container.addEventListener('mousedown', onDocumentMouseDown, false);
    container.addEventListener('touchstart', onDocumentTouchStart, false);
    container.addEventListener('touchmove', onDocumentTouchMove, false);
    window.addEventListener('resize', onWindowResize, false);
    if (STATS_ENABLED) {

        stats = new Stats();
        container.appendChild(stats.dom);
    }



    m = OBJECT[ "obj_one" ].materials;
    mi = OBJECT[ "obj_one" ].init_material;
    OBJECT[ "obj_one" ].mmap = {
        0: m.body[ mi ][ 1 ], // 
        1: m.body[ mi ][ 1 ],
        2: m.body[ mi ][ 1 ]// toppen
                // 2: m.body[ mi ][ 1 ],
                // 3: m.body[ mi ][ 1 ] // hand // toppen
                // 4: m.body[ mi ][ 1 ], // cuff
                //5: m.body[ mi ][ 1 ], //inner-side
                //6: m.body[ mi ][ 1 ], //collar
                //7: m.body[ mi ][ 1 ], //buttons
                // 8: m.body[ mi ][ 1 ] //body



    };

    loader.load(OBJECT[ "obj_one" ].url, function(geometry) {
        createScene(geometry, "obj_one");
    });

    setTimeout(function() {
        jQuery(".suit-preloader").hide();
    }, 500);

}

jQuery("#canvasHolder").on("mousedown", function() {

    jQuery(".drag-rotate").fadeOut(3000);
    jQuery("body").css({"cursor": "move"});

});

jQuery("#canvasHolder").on("mouseup", function() {


    jQuery("body").css({"cursor": "pointer"});

});

function $(id) {
    return document.getElementById(id);
}
function button_name(bottle, index) {
    return "m_" + bottle + "_" + index
}



function createButtons(materials, bottle) {

    var buttons, i, src = "";
    for (i = 0; i < materials.length; i++) {

        src += '<li type="' + materials[ i ][ 0 ].split("_")[1] + '" id="' + button_name(bottle, i) + '" onclick="changeColor(this)"><img width="90" height="90" src="'+ materials[ i ][ 0 ].split("_")[0] + '"/></li> ';
    }

    buttons = document.createElement("ul");
    buttons.innerHTML = src;
    document.getElementById("socks-textures").appendChild(buttons);
    return buttons;
}

function attachButtonMaterials(materials, faceMaterial, material_indices, bottle) {

    for (var i = 0; i < materials.length; i++) {

        document.getElementById(button_name(bottle, i)).counter = i;
        document.getElementById(button_name(bottle, i)).addEventListener('click', function() {
            // var materialImg = materials[ this.counter ][ 0 ].split("_")[1];
            var materialImg = materials[ this.counter ][ 0 ].split("_")[0];
            materials[ this.counter ][ 0 ] = materialImg;

            console.log(materials[ this.counter ][ 0 ]);
            if (bottle == 'obj_one')
            {
                var selPart = document.querySelector('input[name="optColor"]:checked').value;


                //console.log(materials[ this.counter ][ 0 ]);
                if (selPart == 'body') {
                    //faceMaterial.materials[3] = materials[ this.counter ][ 1 ];
                    faceMaterial.materials[0] = materials[ this.counter ][ 1 ];
                }

                if (selPart == 'cuff') {
                    faceMaterial.materials[1] = materials[ this.counter ][ 1 ];
                    faceMaterial.materials[2] = materials[ this.counter ][ 1 ];
                }



                return;
            }

            for (var j = 0; j < material_indices.length; j++) {



                faceMaterial.materials[ material_indices [ j ] ] = materials[ this.counter ][ 1 ];
            }

        }, false);
    }

    setTimeout(function() {
        jQuery("#theInitialProgress").hide();
        jQuery("#options").hide();
        jQuery("#leftPanel").hide();
        jQuery("#socks-textures ul li").eq(0).trigger("click");
        jQuery("#socks-styles ul li").eq(3).trigger("click");


    }, 1000);

}





var theCurrentObjM;
function createScene(geometry, bottle) {

    geometry.sortFacesByMaterialIndex();
    theCurrentObjM = new THREE.MultiMaterial(),
            s = OBJECT[ bottle ].scale * 2,
            r = OBJECT[ bottle ].init_rotation,
            materials = OBJECT[ bottle ].materials,
            mi = OBJECT[ bottle ].init_material,
            bm = OBJECT[ bottle ].body_materials;
    for (var i in OBJECT[ bottle ].mmap) {

        theCurrentObjM.materials[ i ] = OBJECT[ bottle ].mmap[ i ];
    }

    obj = new THREE.Mesh(geometry, theCurrentObjM);
    scene.add(obj);
    OBJECT[ bottle ].buttons = createButtons(materials.body, bottle);
    attachButtonMaterials(materials.body, theCurrentObjM, bm, bottle);
    //switchCar(car);
}



function onWindowResize() {

    //windowHalfX = window.innerWidth / 2;
    renderer.setViewport(0, 0, canvasWt, canvasHt);
    camera.aspect = canvasWt / canvasHt;
    camera.updateProjectionMatrix();
    //windowHalfY = window.innerHeight / 2;
    //camera.aspect = window.innerWidth / window.innerHeight;
    //camera.updateProjectionMatrix();
    //renderer.setSize(window.innerWidth, window.innerHeight);
}


function onDocumentMouseDown(event) {

    event.preventDefault();
    document.addEventListener('mousemove', onDocumentMouseMove, false);
    document.addEventListener('mouseup', onDocumentMouseUp, false);
    document.addEventListener('mouseout', onDocumentMouseOut, false);
    mouseXOnMouseDown = event.clientX - canvasWt;
    targetRotationOnMouseDown = targetRotation;
}


function onDocumentMouseMove(event) {

    mouseX = event.clientX - canvasWt;
    targetRotation = targetRotationOnMouseDown + (mouseX - mouseXOnMouseDown) * 0.02;

}


function onDocumentMouseUp(event) {

    document.removeEventListener('mousemove', onDocumentMouseMove, false);
    document.removeEventListener('mouseup', onDocumentMouseUp, false);
    document.removeEventListener('mouseout', onDocumentMouseOut, false);
}


function onDocumentMouseOut(event) {

    document.removeEventListener('mousemove', onDocumentMouseMove, false);
    document.removeEventListener('mouseup', onDocumentMouseUp, false);
    document.removeEventListener('mouseout', onDocumentMouseOut, false);
}


function onDocumentTouchStart(event) {

    if (event.touches.length === 1) {

        event.preventDefault();
        mouseXOnMouseDown = event.touches[ 0 ].pageX - canvasWt;
        targetRotationOnMouseDown = targetRotation;
    }

}


function onDocumentTouchMove(event) {

    if (event.touches.length === 1) {

        event.preventDefault();
        mouseX = event.touches[ 0 ].pageX - canvasWt;
        targetRotation = targetRotationOnMouseDown + (mouseX - mouseXOnMouseDown) * 0.05;
    }

}


function animate() {

    requestAnimationFrame(animate);
    render();
}

function render() {

    if (obj) {
        obj.rotation.y += (targetRotation - obj.rotation.y) * 0.19;
        renderer.render(scene, camera);
    }
}



function changeColor(actObj)
{

    jQuery("#socks-textures").find(".activeClass").removeClass("activeClass");
    jQuery(actObj).addClass("activeClass");
}


function loadStyle() {
    var styles = textureJSON['styles'];
    jQuery("#socks-style ul").html('');
    for (var style in styles)
    {
        jQuery("#socks-style ul").append('<li catid="' + styles[style]["id"] + '" isReady = "' + styles[style]["ready"] + '" title="' + styles[style]["name"] + '"cat_js="' + styles[style]["js"] + '" onClick="loadTemplate(this);"><a href="javascript:void(0);"><img src="' + styles[style]["image"] + '"></a></li>');
    }

}

function loadTextures()
{
    //jQuery(".suit-preloader").show();
    var texture = textureJSON['texture'];

    var colors = textureJSON['colors'];

    jQuery("#socks-textures ul").html('');

    jQuery("#socks-colors ul").html('');
    OBJECT["obj_one"].materials["body"] = [];

    for (var textr in texture)
    {// "Orange": new THREE.MeshLambertMaterial({map: THREE.ImageUtils.loadTexture('textures/01.jpg')}),
        var image = texture[textr]["image"];//+ "_" + texture[textr]["type"];

        mlib[texture[textr]["name"]] = new THREE.MeshLambertMaterial({map: THREE.ImageUtils.loadTexture(image)});

        // mlib[texture[textr]["image"]] = new THREE.MeshLambertMaterial({map: THREE.ImageUtils.loadTexture(texture[textr]["image"])});

        OBJECT["obj_one"].materials["body"].push([image, mlib[texture[textr]["name"]]]);
        // OBJECT["obj_one"].materials["body"].push([textr["image"], mlib[textr["image"]]]);

    }



    //mlib

}


function loadTemplate(obj) {


    var ready = jQuery(obj).attr("isReady");

    if (ready == "1") {
        jQuery("#socks-style").find(".activeClass").removeClass("activeClass");
        jQuery(obj).addClass("activeClass");
        //  

        jQuery(".suit-preloader").show();

        OBJECT.obj_one.url = jQuery(obj).attr("cat_js");
        targetRotation = 0;
        jQuery("#canvasHolder").html('');
        mlib = {};
        OBJECT["obj_one"].materials = {};
        loadTextures();
        init();
    } else {
        alert("Current style is under construction.");
    }



}



//OBJECT.obj_one.url="Suit_obj/groupy.js"
//OBJECT.obj_one.url