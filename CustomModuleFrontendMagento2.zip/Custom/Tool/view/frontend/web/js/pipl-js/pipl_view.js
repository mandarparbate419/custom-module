var textureJSON;
var ajaxPath = "";
var basePath = "";

jQuery(document).ready(function(e) {


    basePath = jQuery("#site_path").val();
    ajaxPath = jQuery("#site_path").val() + "custom-ajax/";



    jQuery.ajax({
        url: ajaxPath + "textures.php",
        success: function(msg) {
            textureJSON = JSON.parse(msg);
            loadTextures();
            loadStyle();
            init();
            animate();


        }
    });
});





