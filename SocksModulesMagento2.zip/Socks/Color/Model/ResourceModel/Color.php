<?php

namespace Socks\Color\Model\ResourceModel;

class Color extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
        
        
           
    protected function _construct()
    {
        $this->_init('socks_color', 'socks_color_id');
    }
}
