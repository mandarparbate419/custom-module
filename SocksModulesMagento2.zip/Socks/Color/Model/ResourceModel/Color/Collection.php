<?php
/**
 * Copyright © 2015 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Socks\Color\Model\ResourceModel\Color;

use \Socks\Color\Model\ResourceModel\AbstractCollection;

class Collection extends AbstractCollection
{
    /**
     * @var string
     */
    protected $_idFieldName = 'socks_color_id';

    /**
     * Load data for preview flag
     *
     * @var bool
     */
    protected $_previewFlag;

    /**
     * Define resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Socks\Color\Model\Color', 'Socks\Color\Model\ResourceModel\Color');
        $this->_map['fields']['socks_color_id'] = 'main_table.socks_color_id';
    }
}
