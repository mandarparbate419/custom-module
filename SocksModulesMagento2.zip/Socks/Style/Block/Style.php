<?php
namespace Socks\Style\Block;

use Magento\Framework\View\Element\Template;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\ObjectManagerInterface;
        
class Style extends Template
{
          
    protected $scopeConfig;
    protected $collectionFactory;
    protected $objectManager;
        
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Socks\Style\Model\ResourceModel\Style\CollectionFactory $collectionFactory,
        ObjectManagerInterface $objectManager
    ) {
        
        $this->scopeConfig = $context->getScopeConfig();
        $this->collectionFactory = $collectionFactory;
        $this->objectManager = $objectManager;
                
        parent::__construct($context);
    }
        
        
    public function getFrontStyle()
    {
                
            
        $collection = $this->collectionFactory->create()->addFieldToFilter('status', 1);
                
        /*
         * cehck for arguments,provided in block call
         */
        if ($ids_list = $this->getStyleBlockArguments()) {
            $collection->addFilter('socks_style_id', ['in' => $ids_list], 'public');
        }
                
                
        return $collection;
    }
                
        
    public function getStyleBlockArguments()
    {
            
        $list =  $this->getStyleList();
                
        $listArray = [];
                
        if ($list != '') {
            $listArray = explode(',', $list);
        }
                
        return $listArray;
    }
        
    public function getMediaDirectoryUrl()
    {
            
        $media_dir = $this->objectManager->get('Magento\Store\Model\StoreManagerInterface')
        ->getStore()
        ->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);
            
        return $media_dir;
    }
}
