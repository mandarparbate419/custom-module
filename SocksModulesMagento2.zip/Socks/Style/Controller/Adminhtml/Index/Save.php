<?php

/**
 *
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Socks\Style\Controller\Adminhtml\Index;

use Magento\Backend\App\Action\Context;
use Magento\Backend\App\Action;
use Socks\Style\Model\Style;
use Magento\Framework\App\Request\DataPersistorInterface;
use Magento\Framework\Exception\LocalizedException;
use Magento\TestFramework\Inspection\Exception;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Store\Model\ScopeInterface;
use Magento\Framework\App\RequestInterface;

//use Magento\Framework\Stdlib\DateTime\DateTime;
//use Magento\Ui\Component\MassAction\Filter;
//use FME\News\Model\ResourceModel\Test\CollectionFactory;

class Save extends \Magento\Backend\App\Action {

    /**
     * @var DataPersistorInterface
     */
    protected $dataPersistor;
    protected $scopeConfig;
    protected $_escaper;
    protected $inlineTranslation;
    protected $_dateFactory;

    //protected $_modelNewsFactory;
    //  protected $collectionFactory;
    //  protected $filter;
    /**
     * @param Context $context
     * @param \Magento\Framework\Registry $coreRegistry
     * @param DataPersistorInterface $dataPersistor
     */
    public function __construct(
    Context $context, DataPersistorInterface $dataPersistor, \Magento\Framework\Escaper $escaper, \Magento\Framework\Translate\Inline\StateInterface $inlineTranslation, \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig, \Magento\Framework\Stdlib\DateTime\DateTimeFactory $dateFactory
    ) {
        // $this->filter = $filter;
        // $this->collectionFactory = $collectionFactory;
        $this->dataPersistor = $dataPersistor;
        $this->scopeConfig = $scopeConfig;
        $this->_escaper = $escaper;
        $this->_dateFactory = $dateFactory;
        $this->inlineTranslation = $inlineTranslation;
        parent::__construct($context);
    }

    /**
     * Save action
     *
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute() {
        $om = \Magento\Framework\App\ObjectManager::getInstance();
        $filesystem = $om->get('Magento\Framework\Filesystem');
        $reader = $filesystem->getDirectoryRead(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA);
        $path = $reader->getAbsolutePath('socks_style');
        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();
        $data = $this->getRequest()->getPostValue();
        if ($data) {
            $id = $this->getRequest()->getParam('socks_style_id');

            if (isset($data['status']) && $data['status'] === 'true') {
                $data['status'] = Block::STATUS_ENABLED;
            }
            if (empty($data['socks_style_id'])) {
                $data['socks_style_id'] = null;
            }


            /** @var \Magento\Cms\Model\Block $model */
            $model = $this->_objectManager->create('Socks\Style\Model\Style')->load($id);
            if (!$model->getId() && $id) {
                $this->messageManager->addError(__('This socks_style no longer exists.'));
                return $resultRedirect->setPath('*/*/');
            }

//echo "<pre>";print_r($data['obj_image'][0]);die;
            if (isset($data['image'][0]['name']) && isset($data['image'][0]['tmp_name'])) {
                $data['image'] = '/socks_style/' . $data['image'][0]['name'];
            } elseif (isset($data['image'][0]['name']) && !isset($data['image'][0]['tmp_name'])) {
                $data['image'] = $data['image'][0]['name'];
            } else {
                $data['image'] = null;
            }

            if (isset($data['mtl_image'][0]['name']) && isset($data['mtl_image'][0]['tmp_name'])) {
                $data['mtl_image'] = '/socks_style/' . $data['mtl_image'][0]['name'];
            } elseif (isset($data['mtl_image'][0]['name']) && !isset($data['image'][0]['tmp_name'])) {
                $data['mtl_image'] = $data['mtl_image'][0]['name'];
            } else {
                $data['mtl_image'] = null;
            }

            if (isset($data['obj_image'][0]['name']) && isset($data['obj_image'][0]['tmp_name'])) {
                
//                 $data['obj_image'] = '/socks_style/' . $data['obj_image'][0]['name'];
                $file_name = $data['obj_image'][0]['name'];
                $ext = pathinfo($file_name, PATHINFO_EXTENSION);
                list($Objfile, $ext) = explode(".", $file_name);
                $Objectfile = $file_name;
                $data['obj_image'] = 'style_images/' . $Objectfile;
              
                exec('python ' . $path . "/" . 'convert_obj_three.py -i ' . $path . "/" . $Objectfile . ' -b -o ' . $path . "/" . $Objfile . '.js');
                exec('python ' . $path . "/" . 'convert_obj_three.py -i ' . $path . "/" . $Objectfile . ' -t binary -s smooth -o ' . $path . "/" . $Objfile . '.js');
                $data['obj_image'] = '/socks_style/' . $Objectfile;
                $data['js_file'] = '/socks_style/' . $Objfile . '.js';
                $data['bin_file'] = '/socks_style/' . $Objfile . '.bin';
            } elseif (isset($data['obj_image'][0]['name']) && !isset($data['image'][0]['tmp_name'])) {
                $data['obj_image'] = $data['obj_image'][0]['name'];
            } else {
                $data['obj_image'] = null;
            }

            $model->setData($data);


            $this->inlineTranslation->suspend();
            try {
                //////////////////// email
                $model->save();
                $this->messageManager->addSuccess(__('socks_style Saved successfully'));
                $this->dataPersistor->clear('socks_style');

                if ($this->getRequest()->getParam('back')) {
                    return $resultRedirect->setPath('*/*/edit', ['socks_style_id' => $model->getId()]);
                }
                return $resultRedirect->setPath('*/*/');
            } catch (LocalizedException $e) {
                $this->messageManager->addError($e->getMessage());
            } catch (\Exception $e) {
                $this->messageManager->addException($e, __('Something went wrong while saving the socks_style.'));
            }

            $this->dataPersistor->set('socks_style', $data);
            return $resultRedirect->setPath('*/*/edit', ['socks_style_id' => $this->getRequest()->getParam('socks_style_id')]);
        }
        return $resultRedirect->setPath('*/*/');
    }

}
