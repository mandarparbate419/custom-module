<?php

/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Socks\Style\Model\Style;

use Socks\Style\Model\ResourceModel\Style\CollectionFactory;
use Magento\Framework\App\Request\DataPersistorInterface;

/**
 * Class DataProvider
 */
class DataProvider extends \Magento\Ui\DataProvider\AbstractDataProvider {

    /**
     * @var \Magento\Cms\Model\ResourceModel\Block\Collection
     */
    protected $collection;

    /**
     * @var DataPersistorInterface
     */
    protected $dataPersistor;
    public $_storeManager;

    /**
     * @var array
     */
    protected $loadedData;

    /**
     * Constructor
     *
     * @param string $name
     * @param string $primaryFieldName
     * @param string $requestFieldName
     * @param CollectionFactory $blockCollectionFactory
     * @param DataPersistorInterface $dataPersistor
     * @param array $meta
     * @param array $data
     */
    public function __construct(
    $name, $primaryFieldName, $requestFieldName, CollectionFactory $blockCollectionFactory, DataPersistorInterface $dataPersistor, \Magento\Store\Model\StoreManagerInterface $storeManager, array $meta = [], array $data = []
    ) {
        $this->collection = $blockCollectionFactory->create();
        $this->_storeManager = $storeManager;
        $this->dataPersistor = $dataPersistor;
        parent::__construct($name, $primaryFieldName, $requestFieldName, $meta, $data);
    }

    /**
     * Get data
     *
     * @return array
     */
    public function getData() {
        $temp=[];
        $tempthread=[];
        $baseurl = $this->_storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);
        if (isset($this->loadedData)) {
            return $this->loadedData;
        }
        $items = $this->collection->getItems();
        /** @var \Magento\Cms\Model\Block $block */
        foreach ($items as $block) {
            $this->loadedData[$block->getId()] = $block->getData();


            $temp = $block->getData();
            $img = [];
            $img[0]['name'] = $temp['image'];
            $img[0]['url'] = $baseurl . $temp['image'];
            $temp['image'] = $img;
            
            $mtlImg = [];
            $mtlImg[0]['name'] = $temp['mtl_image'];
            $mtlImg[0]['url'] = $baseurl . $temp['mtl_image'];
            $temp['mtl_image'] = $mtlImg;
            
            $objImg = [];
            $objImg[0]['name'] = $temp['obj_image'];
            $objImg[0]['url'] = $baseurl . $temp['obj_image'];
            $temp['obj_image'] = $objImg;
//
//            $tempthread = $block->getData();
//            $imgthread = [];
//            $imgthread[0]['name'] = $tempthread['socks_stylethreadimage'];
//            $imgthread[0]['url'] = $baseurl . $tempthread['socks_stylethreadimage'];
//            $tempthread['socks_stylethreadimage'] = $imgthread;
        }






        $data = $this->dataPersistor->get('socks_style');

        if (!empty($data)) {
            $block = $this->collection->getNewEmptyItem();
            $block->setData($data);



            $this->loadedData[$block->getId()] = $block->getData();

            $this->dataPersistor->clear('socks_style');
        }

        if (empty($this->loadedData)) {
            return $this->loadedData;
        } else {
            if ($block->getData('image') != null && $block->getData('mtl_image') != null && $block->getData('obj_image') != null) {
                $t2[$block->getId()] = $temp;
                return $t2;
            } else {
                return $this->loadedData;
            }
//            if ($block->getData('socks_stylethreadimage') != null) {
//                $t2thread[$block->getId()] = $tempthread;
//                return $t2thread;
//            } else {
//                return $this->loadedData;
//            }
        }
    }

}
