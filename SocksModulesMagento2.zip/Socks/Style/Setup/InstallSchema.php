<?php

namespace Socks\Style\Setup;

use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;

class InstallSchema implements InstallSchemaInterface {

    public function install(SchemaSetupInterface $setup, ModuleContextInterface $context) {


        $installer = $setup;
        $installer->startSetup();


        /**
         * Create table 'socks_style'
         */
        $table = $installer->getConnection()->newTable($installer->getTable('socks_style'))
                ->addColumn(
                        'socks_style_id', \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER, null, ['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true], 'Styles ID'
                )
                ->addColumn(
                        'name', \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, 255, ['nullable' => true, 'default' => null], 'Title'
                )
                ->addColumn(
                        'price', \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER, null, ['nullable' => false, 'unsigned' => true, 'default' => '0'], 'Price'
                )                
                ->addColumn(
                        'image', \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, 255, [], 'Style Image'
                )
                ->addColumn(
                        'mtl_image', \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, 255, [], 'Material File'
                )
                ->addColumn(
                        'obj_image', \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, 255, [], 'Object File'
                )
                ->addColumn(
                        'js_file', \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, 255, [], 'Object File'
                )
                ->addColumn(
                        'bin_file', \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, 255, [], 'Object File'
                )
//                ->addColumn(
//                        'type', \Magento\Framework\DB\Ddl\Table::TYPE_SMALLINT, null, ['nullable' => false, 'unsigned' => true, 'default' => '0'], 'type'
//                )                
                ->addColumn(
                        'sort_order', \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER, null, ['nullable' => false, 'unsigned' => true, 'default' => '0'], 'Sort Order'
                )
                ->addColumn(
                        'status', \Magento\Framework\DB\Ddl\Table::TYPE_SMALLINT, null, ['nullable' => false, 'unsigned' => true, 'default' => '1'], 'Date'
                )
                ->addColumn(
                        'created_time', \Magento\Framework\DB\Ddl\Table::TYPE_TIMESTAMP, null, ['nullable' => false, 'default' => \Magento\Framework\DB\Ddl\Table::TIMESTAMP_INIT], 'Creation Time'
                )
                ->addColumn(
                'update_time', \Magento\Framework\DB\Ddl\Table::TYPE_TIMESTAMP, null, ['nullable' => false, 'default' => \Magento\Framework\DB\Ddl\Table::TIMESTAMP_INIT_UPDATE], 'Update Time'
        );


        $installer->getConnection()->createTable($table);

        $installer->endSetup();
    }

}
