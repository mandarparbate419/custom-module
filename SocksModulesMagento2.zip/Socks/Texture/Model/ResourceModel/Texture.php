<?php

namespace Socks\Texture\Model\ResourceModel;

class Texture extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
        
        
           
    protected function _construct()
    {
        $this->_init('socks_texture', 'socks_texture_id');
    }
}
