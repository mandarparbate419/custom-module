<?php
/**
 * Copyright © 2015 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Socks\Texture\Model\ResourceModel\Texture;

use \Socks\Texture\Model\ResourceModel\AbstractCollection;

class Collection extends AbstractCollection
{
    /**
     * @var string
     */
    protected $_idFieldName = 'socks_texture_id';

    /**
     * Load data for preview flag
     *
     * @var bool
     */
    protected $_previewFlag;

    /**
     * Define resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Socks\Texture\Model\Texture', 'Socks\Texture\Model\ResourceModel\Texture');
        $this->_map['fields']['socks_texture_id'] = 'main_table.socks_texture_id';
    }
}
