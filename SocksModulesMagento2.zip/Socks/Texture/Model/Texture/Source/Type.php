<?php
/**
 * Copyright © 2015 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Socks\Texture\Model\Texture\Source;

use Magento\Framework\Data\OptionSourceInterface;

/**
 * Class Status
 */
class Type implements OptionSourceInterface
{
    
    /**
     * Get options
     *
     * @return array
     */
    public function toOptionArray()
    {
        
        return [
            ['value' => '0', 'label' => __('texture')],
            ['value' => '1', 'label' => __('color')]            
        ];
    }
}
